#include <stdio.h>

int main()
{
    int a;
    int b;
    


    printf("Digite o valor de A: ");
    scanf("%d", &b);
    
    printf("Digite o valor de B: ");
    scanf("%d", &a);

    printf("O valor de A igual a %d\n" , a);
    printf("O valor de B igual a %d\n" , b);

    return 0;

}