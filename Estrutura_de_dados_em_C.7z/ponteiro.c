#include <stdio.h>

int main(){
    vetor[3] = {1 , 2 , 3} ;
    int Ponteiro = vetor

    int *Ponteiro = &vetor[0];
    printf("%x\n", Ponteiro);

    int *Ponteiro = &vetor[1];
    printf("%x\n", Ponteiro);

    int *Ponteiro = &vetor[2];
    printf("%x\n", Ponteiro);

    ++Ponteiro;
    *(Ponteiro + 1) = 10

    return 0;

}